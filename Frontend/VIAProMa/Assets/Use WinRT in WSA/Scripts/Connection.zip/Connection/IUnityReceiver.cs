﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UWPConnection
{
    /// <summary>
    /// You need to implement this interface to listen to messages sent from Unity.
    /// </summary>
    /// <remarks>
    /// You need to create the Communications object passing an implementation of this interface as parameter.
    /// Please consult the documentations for more details on how to set it up.
    /// </remarks>
    public interface IUnityReceiver
    {
        /// <summary>
        /// Receive a message sent from your Unity scripts. Your WSA code goes here.
        /// </summary>
        /// <param name="arg">
        /// This is the message sent from your Unity scripts. Note that you only have this function to receive info from Unity,
        /// and that you only have this parameter to encode it. However, you may possibly have many kind of “messages” and data types
        /// to receive from your Unity script. You need to encode all of that using this parameter.
        /// If you need some ideas on how to do this, please study the example implementation and consult the documentation.
        /// </param>
        void ReceiveFromUnity(object arg);
    }
}
