﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using UnityEngine;
using UnityEngine.Windows;


namespace UWPConnection
{
    

    /// <summary>
    /// This class manage the connection between your Unity scripts and your WSA Project on the latter side.
    /// </summary>
    public sealed class Communications
    {
        /// <summary>
        /// Create and setup the connection.
        /// This class will listen to the messages you send using the UWPConnectionManager object in Unity. It also enables you to send messages back in an appropriate way.
        /// It must be created once the WinRTBridged has been initialized. Please refer to the documentation for more details about how to set it up.
        /// </summary>
        /// <param name="receiver">An IUnityRecever object, that you need to implement, to receive messages from your Unity scripts.</param>
        public Communications(IUnityReceiver receiver)
        {
            Receiver = receiver;
            SetEvent();
        }

        private static IUnityReceiver Receiver;
        private static UnityEngine.GameObject UWPConnectionManagerObject;

        private static UnityEngine.GameObject GetUWPConnetionManagerObject()
        {

            if (UWPConnectionManagerObject == null)
                UWPConnectionManagerObject = UnityEngine.GameObject.Find("UWPConnectionManager");

            return UWPConnectionManagerObject;
        }

        /// <summary>
        /// Register this class to receive events from the UWPConnectionManager object in Unity.
        /// </summary>
        private void SetEvent()
        {

            UnityPlayer.AppCallbacks.Instance.InvokeOnAppThread(new UnityPlayer.AppCallbackItem(() =>
            {
                if (GetUWPConnetionManagerObject() != null)
                {
                    GetUWPConnetionManagerObject().GetComponent<UWPConnectionManager>().onEvent = new UWPConnectionManager.OnEvent(UnityToXAML);
                }
                else
                {
                    throw new Exception("UWPConnectionManager not found, have you exported the correct scene?");
                }
            }), true);

        }


        private static void UnityToXAML(object arg)
        {

            UnityPlayer.AppCallbacks.Instance.InvokeOnUIThread(new UnityPlayer.AppCallbackItem(() =>
            {

                Receiver.ReceiveFromUnity(arg);
            }
            ), false);

        }

        /// <summary>
        /// Call this function when you need to communicate with your Unity scripts.
        /// The UWPConnectionManager game object in Unity will receive this message and relay it to your own scripts.
        /// </summary>
        /// <param name="arg">Use this parameter to encode the message that you want to send to your Unity scripts. They will receive this object as you pass it here.
        /// Please refer to the example and documentation for a further explanation on how you can use this sole function for proper communication.
        /// </param>
        public static void SendToUnity(object arg)
        {
            if (GetUWPConnetionManagerObject() != null)
            {

                if (UnityPlayer.AppCallbacks.Instance.IsInitialized())
                {
                    UnityPlayer.AppCallbacks.Instance.InvokeOnAppThread(new UnityPlayer.AppCallbackItem(() =>
                    {
                        GetUWPConnetionManagerObject().GetComponent<UWPConnectionManager>().ReceiveFromUWP(arg);
                    }
                    ), false);
                }
            }
            else
            {
                throw new Exception("UWPConnectionManager not found. Have exported the correct scene?");
            }
        }

    }
}