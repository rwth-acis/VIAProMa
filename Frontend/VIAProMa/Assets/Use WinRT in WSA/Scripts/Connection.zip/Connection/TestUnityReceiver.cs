﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Media.SpeechRecognition;
using Windows.Media.SpeechSynthesis;
using Windows.UI.Xaml.Controls;

namespace UWPConnection
{
    /// <summary>
    /// This is an example implementation for the IUnityReceiver interface.
    /// You need to implement this interface in order to listen to messages generated from your Unity scripts.
    /// Ideally, the mission of the IUnityReceiver implementing class is to receive and classify those messages, and then invoke functions
    /// (that can be in other classes or, as it's the case, in this one) depending on the nature of the message received. Think of this as a relay class
    /// for your messages.
    /// </summary>
    /// <remarks>
    /// In this example, an UWP standard dialog is shown, and some uses of the WinRT Speech API are done. The voice recognition function (SpeechRecognitionWithUI)
    /// in particular is interesting because it will communicate back the results to Unity once the recognition is done.
    /// </remarks>
    class TestUnityReceiver : IUnityReceiver
    {
        /// <summary>
        /// An example implementation for the demo app provided with the Asset. Three messages are received from the Unity scripts: To show a UWP dialog, to use the
        /// Speech API to narrate a text, and to perform some speech recognition and send it back to Unity.
        /// </summary>
        /// <param name="arg">
        /// In this example it is assumed that arg is an array of string. Else, the call is ignored. The first element of the array is taken as a “command” description.
        /// Further elements are taken as parameters.
        /// </param>
        public void ReceiveFromUnity(object arg)
        {
            if (arg is string[])
            {
                var commands = arg as string[];
                switch (commands[0])
                {
                    case "Dialog":
                        displayUWPDialogAsync();
                        break;
                    case "Narrate":
                        if (commands.Length >= 2)
                            NarrateAsync(commands[1]);
                        else
                            NarrateAsync();
                        break;
                    case "Speech":
                        SpeechRecognitionWithUI();
                        break;
                }
            }
        }

        private async void NarrateAsync(string text = "This is a default narration text")
        {
            // The media object for controlling and playing audio.
            MediaElement mediaElement = new MediaElement();//this.media;

            // The object for controlling the speech synthesis engine (voice).
            var synth = new Windows.Media.SpeechSynthesis.SpeechSynthesizer();

            // Generate the audio stream from plain text.
            SpeechSynthesisStream stream = await synth.SynthesizeTextToStreamAsync(text);

            // Send the stream to the media object.
            mediaElement.SetSource(stream, stream.ContentType);
            mediaElement.Play();
        }

        private async void SpeechRecognitionWithUI()
        {

            var recognizerWithUI = new SpeechRecognizer();
            await recognizerWithUI.CompileConstraintsAsync();

            try
            {
                SpeechRecognitionResult recognizerResult = await recognizerWithUI.RecognizeWithUIAsync();
                //Send the resutls back to Unity for processing.
                Communications.SendToUnity(recognizerResult.Text);
            }
            // Catch errors related to the recognition operation.
            catch (Exception err)
            {
                // Define a variable that holds the error for the speech recognition privacy policy. 
                // This value maps to the SPERR_SPEECH_PRIVACY_POLICY_NOT_ACCEPTED error, 
                // as described in the Windows.Phone.Speech.Recognition error codes section later on.
                const int privacyPolicyHResult = unchecked((int)0x80045509);

                // Check whether the error is for the speech recognition privacy policy.
                if (err.HResult == privacyPolicyHResult)
                {
                    displayUWPDialogAsync("Privacy policy restriction", "You will need to accept the speech privacy policy in order to use speech recognition in this app.\nGo to Settings -> Privacy -> Speech, inking, & typing, and enable \"Get to know me\"");
                }
                else
                {
                    // Handle other types of errors here. Beyond the scope of this test / demo.
                }
            }
        }


        private async void displayUWPDialogAsync(string title = "An UWP dialog", string content = "This dialog has been summoned from Unity", string primaryButtonText = "Ok")
        {
            ContentDialog UWPDialog = new ContentDialog()
            {
                Title = title,
                Content = content,
                PrimaryButtonText = primaryButtonText
            };

            ContentDialogResult result = await UWPDialog.ShowAsync();
        }
    }
}
